package pkg.enums;

public enum GameType {
	COMPUTER,
	COMPETITION
}
