

use tictactoe;

CREATE TABLE IF NOT EXISTS player (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  user_name varchar(64) DEFAULT NULL,
  password varchar(128) DEFAULT NULL,
  email varchar(128),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;