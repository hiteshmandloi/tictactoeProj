

use tictactoe;

CREATE TABLE IF NOT EXISTS game (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  first_player_id bigint(20) NOT NULL,
  second_player_id bigint(20),
  created timestamp,
  game_status varchar(255) DEFAULT NULL,
  game_type varchar(255) DEFAULT NULL,
  first_player_piece_code char(1),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;