package pkg.entity;

public class Position {
	int boardRow;
	int boardColumn;

	public Position(int row, int col) {
		this.boardRow = row;
		this.boardColumn = col;
	}

	public int getBoardRow() {
		return boardRow;
	}

	public void setBoardRow(int boardRow) {
		this.boardRow = boardRow;
	}

	public int getBoardColumn() {
		return boardColumn;
	}

	public void setBoardColumn(int boardColumn) {
		this.boardColumn = boardColumn;
	}

}