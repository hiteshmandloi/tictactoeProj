

use tictactoe;

CREATE TABLE IF NOT EXISTS move (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  player_id bigint(20) NOT NULL,
  game_id bigint(20) NOT NULL,
  board_row bigint(20) DEFAULT NULL,
  board_column bigint(20) DEFAULT NULL,
  created timestamp,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;