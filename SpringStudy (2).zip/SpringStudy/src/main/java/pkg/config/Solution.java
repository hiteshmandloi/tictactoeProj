package pkg.config;

import java.util.Arrays;

class Solution {
    public int solution(int[] A) {
        // write your code in Java SE 8
        int max=0;
        for(int i=0;i<A.length;i++) {
            if(A[i] > max) {
                max = A[i];
            }
        }
        boolean flag = false;
        int min = 1;
        int finalValue = 0;
        Arrays.sort(A);
        for(int i=1;i<=max;i++) {
            for(int j=0;j<A.length;j++) {
                if(i == A[j]) {
                    flag = true;
                }
            }
            if(!flag) {
                finalValue = i;
                break;
            }

        }
        System.out.println("final value is->" + finalValue);
		return finalValue;
    }

    public static void main() {
        Solution s1 = new Solution();
        int A[] = {1, 3, 6, 4, 1, 2};
        s1.solution(A);
    }
}