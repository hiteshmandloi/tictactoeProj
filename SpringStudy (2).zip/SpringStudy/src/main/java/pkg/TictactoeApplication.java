package pkg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan
public class TictactoeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TictactoeApplication.class, args);
	}

//	@Bean
//	public CommandLineRunner demo(PlayerRepository playerRepository) {
//		return (args) -> {
//
//			// save a couple of players
//			playerRepository.save(new Player("ala", "ala@ala.com", new BCryptPasswordEncoder().encode("ala")));
//			playerRepository.save(new Player("mary", "mary@mary.com", new BCryptPasswordEncoder().encode("mary")));
//
//		};
//	}
}
