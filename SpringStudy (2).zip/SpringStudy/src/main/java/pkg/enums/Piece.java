package pkg.enums;

public enum Piece {
	X,
	O
}
